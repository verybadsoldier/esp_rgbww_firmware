import{c as e}from"./index.js";var r=({app:a})=>{a.use(e())};export{r as default};
